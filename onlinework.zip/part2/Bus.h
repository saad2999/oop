#ifndef SDDS_EGGCARTON_H
#define SDDS_EGGCARTON_H

const double BusTicket = 125.34;
#include <iostream>
using namespace std;
namespace sdds {
	class Bus {
		
		void OutOfService();
		int  noOfSeats;
		int noOfPassngers;
		void drawBus(ostream& ostr, int seats, int psng)const;
	
	public:
		
		Bus(int noOfSeats, int noOfPassngers);
		Bus();
		Bus(int  noOfSeats);
		Bus(Bus& right);
		
		Bus& operator=(int value);

		Bus& operator+=(int value);
		Bus& operator+=(Bus& right);
		bool operator==(const Bus& right) const;
		int getnoOfPassngers() const;
		void setnoOfPassngers(int egg) ;
		
		void setnoOfSeats(int  noOfSeats);
		int getnoOfSeats() const;
		bool operator-- ();
		bool operator--(int);
		bool operator++(int);
		bool operator++();
		operator bool() const;
		operator int() const;
		operator double() const;
	 friend	ostream& operator<<(ostream& ostr, const Bus& right);
	};
	ostream& operator<<(ostream& ostr, const Bus& right);
	int operator+(int left, const Bus& right);

	istream& operator>>(istream& istr, Bus& right);
	


}
#endif