#include "EggCarton.h"
using namespace std;
namespace sdds {
	void EggCarton::setBroken()
	{
		this->size = -1;
		this->noOfEggs = -1;
		this->jumboSize = false;
	}
	EggCarton::EggCarton(int size = 6, int noOfEggs = 0, bool jumboSize = false)
	{
		if ((size >= 6 && size <= 36) && (size % 6 == 0) && (noOfEggs >= 0 && noOfEggs <= size))
		{
			this->size = size;
			this->noOfEggs = noOfEggs;
			this->jumboSize = jumboSize;
			

		}
		else
		{
			setBroken();
		}
	}

	EggCarton::EggCarton()
	{
		size = 6;
		noOfEggs = 0;
		jumboSize = false;

	}

	EggCarton::EggCarton(int size)
	{
		this->size = size;
		noOfEggs = 0;
		jumboSize = false;
	}

	EggCarton::EggCarton(int size, int noOfeggs)
	{
		this->size = size;
		noOfEggs = noOfeggs;
		jumboSize = false;
	}

	EggCarton::EggCarton(EggCarton& right)
	{
		size = right.size;
		noOfEggs = right.noOfEggs;
		jumboSize = right.jumboSize;
	}

	
	
	
	EggCarton& EggCarton::operator=(int value)
	{
		if(noOfEggs >= 0 && noOfEggs <= this->size)
		{
			
			this->noOfEggs = value;
			return *this;


		}
		else
		{
			setBroken();
			return *this;
		}
	}
	
	EggCarton& EggCarton::operator+=(int value)
	{
		this->noOfEggs += value;
		if (noOfEggs >= 0 && noOfEggs <= this->size)
		{

			this->noOfEggs = value;
			return *this;


		}
		else
		{
			setBroken();
			return *this;
		}
	}

	EggCarton& EggCarton::operator+=(EggCarton& right)
	{
		if (noOfEggs != -1 && noOfEggs < size)
		{
			int mod = this->noOfEggs % 6;
			int emptySpot = mod - 6;
			int excede = right.noOfEggs - emptySpot;
			noOfEggs = right.noOfEggs;
			noOfEggs -= excede;
			right.noOfEggs -= emptySpot;
			return *this;
		}
	}

	bool EggCarton::operator==(const EggCarton& right) const
	{
		if (jumboSize == right.jumboSize)
		{
			if (jumboSize == false)
			{
				float currentCurtonweight = (noOfEggs * RegularEggWieght) / 1000.0;
				float rightCurtonweight = (right.noOfEggs * RegularEggWieght) / 1000.0;
				bool check = currentCurtonweight == rightCurtonweight;
				return check;
			}
			else if (jumboSize == true)
			{
				float currentCurtonweight = (noOfEggs * JumboEggWieght) / 1000.0;
				float rightCurtonweight = (right.noOfEggs * JumboEggWieght) / 1000.0;
				bool check = currentCurtonweight == rightCurtonweight;
			}
		}
		else
		{
			return false;
		}
		

		
	}

	int EggCarton::getnoOfEggs() const
	{
		return noOfEggs;
	}

	void EggCarton::setnoOfEggs(int egg)
	{
		noOfEggs = egg;
	}

	bool EggCarton::Jumbosize() const
	{
		return jumboSize;
	}

	void EggCarton::Jumbosize(bool var)
	{
		this->jumboSize = var;
	}

	void EggCarton::setsize(int Size)
	{
		size = Size;
	}

	int EggCarton::getsize() const
	{
		return size;
	}

	EggCarton& EggCarton::operator--()
	{
		EggCarton obj=*this;
		if (noOfEggs > 0)
		{
				obj=--noOfEggs;
		}
		return obj;
	}
	EggCarton& EggCarton::operator--(int)
	{
		EggCarton obj = *this;
		if (noOfEggs > 0)
		{
			obj=noOfEggs--;
		}
		return obj;
	}
	EggCarton& EggCarton::operator++(int)
	{
		EggCarton obj = *this;
		if (noOfEggs > 0)
		{
			obj =noOfEggs++;
		}
		return obj;
	}
	EggCarton& EggCarton::operator++()
	{
		EggCarton obj = *this;
		if (noOfEggs > 0)
		{
			obj= ++noOfEggs;
		}
		return obj;
	}
	EggCarton::operator bool() const
	{
		if (noOfEggs != -1 && size != -1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	EggCarton::operator int() const
	{
		return noOfEggs;
	}

	EggCarton::operator double() const
	{
		if (jumboSize == true)
		{
			double var = ((noOfEggs * JumboEggWieght) / 1000.0);
			return var;

		}
		else
		{
			double var = ((noOfEggs * RegularEggWieght) / 1000.0);
			return var;
		}
	}

	
	
 

 
	ostream& operator<<(ostream& ostr, const EggCarton& right)
	{
		bool m_jumbo =right.Jumbosize();
		int m_size=right.getsize();
	  const	int m_noOfEggs=right.getnoOfEggs();

		// displays an Egg Carton
		int cartonWidth = m_size == 6 ? 3 : 6;
		for (int i = 0; i < m_size; i++) {
			ostr << ((i < m_noOfEggs) ? (m_jumbo ? 'O' : 'o') : '~');
			if ((i + 1) % cartonWidth == 0) ostr << endl;
		}
		return ostr;

	}

	int operator+(int left, const EggCarton& right)
	{
		if (right.getnoOfEggs() != -1)
		{
			return left + right.getnoOfEggs();
		}
		else
		{
			return left;
		}
	}

	istream& operator>>(istream& istr, EggCarton& right)
	{
		char c;
		int eggnumber;
		int Size;
		istr >> c;
		istr.ignore();
		istr >> Size;
		istr >> eggnumber;
		if (c == 'j')
		{
			right.setsize(true);
		}
		else
		{
			right.Jumbosize(false);
		}
		right.setsize( Size);
		right.setnoOfEggs(eggnumber);
		return istr;
	}

	

}