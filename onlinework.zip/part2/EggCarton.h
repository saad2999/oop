#ifndef SDDS_EGGCARTON_H
#define SDDS_EGGCARTON_H


const int RegularEggWieght = 50;
const int JumboEggWieght = 75;
#include <iostream>
using namespace std;
namespace sdds {
	class EggCarton {
		
		void setBroken();
		int size;
		int noOfEggs;
		bool jumboSize;
	public:
		
		EggCarton(int size, int noOfEggs, bool jumboSize);
		EggCarton();
		EggCarton(int size);
		EggCarton(int size,int noOfeggs);
		EggCarton(EggCarton& right);
		
		EggCarton& operator=(int value);

		EggCarton& operator+=(int value);
		EggCarton& operator+=(EggCarton& right);
		bool operator==(const EggCarton& right) const;
		int getnoOfEggs() const;
		void setnoOfEggs(int egg) ;
		bool Jumbosize()const;
		void Jumbosize(bool var);
		void setsize(int Size);
		int getsize() const;
		EggCarton& operator-- ();
		EggCarton& operator--(int);
		EggCarton& operator++(int);
		EggCarton& operator++();
		operator bool() const;
		operator int() const;
		operator double() const;

	};
	ostream& operator<<(ostream& ostr, const EggCarton& right);
	int operator+(int left, const EggCarton& right);

	istream& operator>>(istream& istr, EggCarton& right);
	


}
#endif