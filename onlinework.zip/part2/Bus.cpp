#include "Bus.h"
using namespace std;
namespace sdds {
	void Bus::OutOfService()
	{
		this-> noOfSeats = -1;
		this->noOfPassngers = -1;
	
	}
	void Bus::drawBus(ostream& ostr, int seats, int psng) const
	{
		int i, p;
		ostr.fill('_');
		ostr.width((seats / 2) * 3 + 4);
		ostr << "_";
		ostr << endl << "| ";
		for (i = 0, p = -1; i < (seats / 2); i++, ostr << "[" << ((p += 2) < psng ? '2' : ((p == psng) ? '1' : ' ')) << "]");
		ostr << "|_\\_" << endl;
		ostr << "| ";
		ostr.fill(' ');
		ostr.width(((seats / 2) * 3 - 14) / 2);
		ostr << " " << "Seneca College";
		ostr.width(((seats / 2) * 3 - 14) / 2 + (seats % 4 != 0));
		ostr << " " << "    )" << endl;
		ostr << "`---OO";
		ostr.fill('-');
		ostr.width((seats / 2) * 3 - 5);
		ostr << "-" << "O---'" << endl;

	}
	Bus::Bus(int  noOfSeats = 10, int noOfPassngers = 0)
	{
		if (( noOfSeats >= 10 &&  noOfSeats <= 40) && ( noOfSeats % 2 == 0) && (noOfPassngers >= 0 && noOfPassngers <=  noOfSeats))
		{
			this-> noOfSeats =  noOfSeats;
			this->noOfPassngers = noOfPassngers;
			
			

		}
		else
		{
			OutOfService();
		}
	}

	Bus::Bus()
	{
		noOfSeats = 10;
		noOfPassngers = 0;
		  

	}

	Bus::Bus(int  noOfSeats)
	{
		this-> noOfSeats =  noOfSeats;
		noOfPassngers = 0;
		 
	}

	

	Bus::Bus(Bus& right)
	{
		 noOfSeats = right. noOfSeats;
		noOfPassngers = right.noOfPassngers;
		  
	}

	
	
	
	Bus& Bus::operator=(int value)
	{
		if(noOfPassngers >= 0 && noOfPassngers <= this-> noOfSeats)
		{
			
			this->noOfPassngers = value;
			return *this;


		}
		else
		{
			OutOfService();
			return *this;
		}
	}
	
	Bus& Bus::operator+=(int value)
	{
		this->noOfPassngers += value;
		if (noOfPassngers >= 0 && noOfPassngers <= this-> noOfSeats)
		{

			this->noOfPassngers = value;
			return *this;


		}
		else
		{
			OutOfService();
			return *this;
		}
	}

	Bus& Bus::operator+=(Bus& right)
	{
		if (noOfPassngers != -1 && noOfPassngers <  noOfSeats)
		{
			int mod = this->noOfPassngers % 6;
			int emptySpot = mod - 6;
			int excede = right.noOfPassngers - emptySpot;
			noOfPassngers = right.noOfPassngers;
			noOfPassngers -= excede;
			right.noOfPassngers -= emptySpot;
			return *this;
		}
	}

	bool Bus::operator==(const Bus& right) const
	{
		if ((noOfPassngers != -1 && noOfSeats != -1)&&(bool(right))&&(noOfPassngers==right.noOfPassngers)) 
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	int Bus::getnoOfPassngers() const
	{
		return noOfPassngers;
	}

	void Bus::setnoOfPassngers(int noofpassenger)
	{
		noOfPassngers = noofpassenger;
	}

	void Bus::setnoOfSeats(int  noOfSeats)
	{
		 noOfSeats =  noOfSeats;
	}

	int Bus::getnoOfSeats() const
	{
		return  noOfSeats;
	}

	bool Bus::operator--()
	{
		Bus obj=*this;
		if (noOfPassngers > 0)
		{
				obj=--noOfPassngers;
				return true;
		}
		return false;
	}
	bool Bus::operator--(int)
	{
		Bus obj = *this;
		if (noOfPassngers > 0)
		{
			obj=noOfPassngers--;
			return true;
		}
		return false;
	}
	bool Bus::operator++(int)
	{
		Bus obj = *this;
		
		if (noOfPassngers > 0)
		{
			obj =noOfPassngers++;
			return true;
		}
		return false;
	}
	bool Bus::operator++()
	{
		Bus obj = *this;
		if (noOfPassngers > 0)
		{
			obj= ++noOfPassngers;
			return true;
		}
		return false;
	}
	Bus::operator bool() const
	{
		if (noOfPassngers != -1 &&  noOfSeats != -1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	Bus::operator int() const
	{
		return noOfPassngers;
	}

	Bus::operator double() const
	{
		if (noOfPassngers != -1 && noOfSeats != -1)
		{
			double val =(noOfPassngers*BusTicket);
			return val;
		}
		else
		{
			return 1.0;
		}
	}

	
	
 

 
	ostream& operator<<(ostream& ostr, const Bus& right)
	{
		if (right.noOfSeats!=-1&&right.noOfPassngers!=-1)
		{
			right.drawBus(ostr, right.noOfSeats, right.noOfPassngers);
		}
		else
		{
			ostr << "out of service\n";
		}
		
		return ostr;

	}

	int operator+(int left, const Bus& right)
	{
		if (right.getnoOfPassngers() != -1)
		{
			return left + right.getnoOfPassngers();
		}
		else
		{
			return left;
		}
	}

	istream& operator>>(istream& istr, Bus& right)
	{
		int noOfSeats;
		int  noOfPassngers;
		istr >> noOfSeats;
		istr.ignore();
		istr >> noOfPassngers;
		if ((noOfSeats >= 10 && noOfSeats <= 40) && (noOfSeats % 2 == 0) && (noOfPassngers >= 0 && noOfPassngers <= noOfSeats))
		{
			right.setnoOfSeats(noOfSeats);
			right.setnoOfPassngers(noOfPassngers);
		}
		else
		{
			cout << "out of Service\n";
		}
	
		return istr;
	}

	

}